# Mockup approvati – App Lead Laura Romagnoli Atelier

Riferimento visivo per l'interfaccia (iPhone 390 px di larghezza). Ogni schermata c'è in due versioni:
- `.png`: immagine della schermata
- `.html`: stessa schermata in HTML statico, da cui leggere colori, dimensioni e testi

Sono SOLO mockup: dati inventati, nessuna logica. Le regole funzionali sono in SPECIFICHE.md, che prevale in caso di differenze.

1. 01-lista-lead – lista con filtri, gruppi per data di importazione, pulsanti Chiama / WhatsApp
2. 02-selezione-multipla – selezione e spostamento nel cestino
3. 03-scheda-lead – dati, stato, appuntamento, esito con importo, note, storico
4. 04-fissa-appuntamento – pulsanti orari (barrato = pieno, tratteggiato = 1 camerino libero), avviso sovrapposizione
5. 05-calendario – settimana, "Promemoria da inviare oggi", appuntamenti del giorno
6. 06-messaggi – scegli template → contatti → anteprima modificabile → Apri in WhatsApp
7. 07-admin-importa – import CSV/Excel, tipo del file, gestione doppioni
8. 08-admin-riepilogo – numeri, attività della commessa, strumenti

Nota: nella schermata 4 l'esempio mostra il sabato (2 camerini). Da lunedì a venerdì c'è 1 solo camerino e gli orari sono quelli della sezione 7 di SPECIFICHE.md.
Font: Josefin Sans (titoli) e Nunito Sans (testo), da Google Fonts.
